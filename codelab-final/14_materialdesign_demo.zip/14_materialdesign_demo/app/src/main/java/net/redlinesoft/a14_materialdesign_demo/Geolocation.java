package net.redlinesoft.a14_materialdesign_demo;

public class Geolocation {


    // TODO 5 : add geolocation model from jsonschema2pojo


}
