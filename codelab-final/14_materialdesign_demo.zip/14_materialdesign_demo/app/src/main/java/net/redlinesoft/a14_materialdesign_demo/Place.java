package net.redlinesoft.a14_materialdesign_demo;

public class Place {

    // TODO 4 : add place model from jsonschema2pojo


}
