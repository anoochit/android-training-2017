package net.redlinesoft.a14_materialdesign_demo;

public interface ApiInterface {

    // TODO 3 : add request method for place list and nearby place list.


}
